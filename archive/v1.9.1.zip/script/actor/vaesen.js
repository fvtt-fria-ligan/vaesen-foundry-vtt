export class VaesenActor extends Actor {
}
